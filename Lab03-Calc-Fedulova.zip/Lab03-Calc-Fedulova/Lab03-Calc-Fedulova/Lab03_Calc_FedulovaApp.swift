//
//  Lab03_Calc_FedulovaApp.swift
//  Lab03-Calc-Fedulova
//
//  Created by Polina Fedulova on 18.10.2023.
//

import SwiftUI

@main
struct Lab03_Calc_FedulovaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
