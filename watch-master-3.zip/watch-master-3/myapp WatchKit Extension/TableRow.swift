//
//  TableRow.swift
//  watch1 Watch App
//
//  Created by Polina Fedulova on 30.10.2023.
//


import WatchKit

class TableRow: NSObject {
    @IBOutlet weak var recipeName: WKInterfaceLabel!
    @IBOutlet weak var recipeIcon: WKInterfaceImage!
    
}
